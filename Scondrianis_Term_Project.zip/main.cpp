/*******************************
	Assignment   : Final Project
	File Name    : main.cpp
	Created By   : Apostolos Scondrianis
	Submitted On : Monday 15th, June 2020
*******************************/

#include "Flight.cpp"
#include "main.h"

int main(void) {
	cout << "Version 1.0" << endl;
	cout << "Term Project - Flight Management Program in C++" << endl;
	cout << "Produced by: Apostolos Scondrianis" << endl;
	pressEnter();
	
	Flight f;
	f = populate_flight_from_file("flight_info.txt");
	displayHeader();
	
	int choice;
	while((choice = menu())) {
		switch(choice){
			case 1:
				cout <<" option 1;";
				f.show_seat_map();
				pressEnter();
				displayHeader();
				break;
			case 2:
				displayPassengers(f);
				pressEnter();
				displayHeader();
				break;
			case 3:
				addPassenger(f);
				pressEnter();
				displayHeader();
				break;
			case 4:
				removePassenger(f);
				pressEnter();
				displayHeader();
				break;
			case 5:
				saveInformation(f);
				pressEnter();
				displayHeader();
				break;
			case 6:
				cout << "Program terminated.\n";
				exit(1);
				break;
		}
	}
	return 0;
}

void displayHeader() {
	cout << "Please select one of the following options:\n";
	cout << "1. Display Flight Seat Map.\n";
	cout << "2. Display Passengers Information.\n";
	cout << "3. Add a New Passenger.\n";
	cout << "4. Remove an Existing Passenger\n";
	cout << "5. Save data\n";
	cout << "6. Quit.\n\n";
	cout << "Enter your choice: (1, 2, 3, 4, 5 or 6) : ";
}

int menu() {
	char choice;
	while(1) {
		choice = cin.get();
		if(choice == '\n') {
			cout << "You have given an invalid input.";
		} else {
			if(static_cast<int>(choice) - 48 <= 6 && static_cast<int>(choice) - 48 >= 1) {
				cleanStandardInputStream();
				return static_cast<int>(choice) - 48;
			} else {
				cout << "You have given an invalid input. Please give an input between 1 and 6.\n\n";
				cleanStandardInputStream();
			}
		}
		displayHeader();
	}
}

void pressEnter(){
	cout<< "\n<<< Press Return to Continue>>>>\n";
	cin.get();
}

void cleanStandardInputStream (void){
	int leftover;
	do{
		leftover = cin.get();
	} while(leftover !='\n' && leftover != EOF);
}

void displayPassengers(const Flight & source) {
	if(source.getPassengers().size() != 0) {
		cout << setw(20) << setiosflags(ios::left) <<"First Name"<< setw(20) <<"Last Name" << setw(20) << "Phone" << setw(6) << "Row" << setw(6) << "Seat" << setw(5) << "ID"<<endl;
		cout << "-----------------------------------------------------------------------------\n";
		for(int i = 0; i < static_cast<int>(source.getPassengers().size()); i++) {
			cout << setw(20) << source.getPassengers().at(i).getFirstName() << setw(20) << source.getPassengers().at(i).getLastName() << setw(20) << source.getPassengers().at(i).getPhoneNumber() << setw(6) << source.getPassengers().at(i).getSeat().getRow() << setw(6) << source.getPassengers().at(i).getSeat().getSeat() << setw(5) << source.getPassengers().at(i).getID() << endl;
			cout << "-----------------------------------------------------------------------------\n";
		}
	} else {
		cout << "The flight " << source.getFlightName() << " has no passengers yet.\n";
	}
}

void addPassenger(Flight & source) {
	Passenger createdPassenger;
	int ID;
	int done = 1;
	char firstName[20];
	char lastName[20];
	char phoneNumber[13];
	int validName;
	int dashCounter;
	int spaceCounter;
	int validPhoneNumber;
	int existsID;
	int row;
	char seat = 'A';
	int howManyInRow;
	int seatTaken;
	if(static_cast<int>(source.getPassengers().size()) == source.getRows()*source.getSeats()) {
		cout << "Unable to add passengers. The flight is full. Please remove a passenger in order to add another one.\n";
	} else {
		while(done) {
			cout << "Please enter the passenger ID : ";
			cin >> ID;
			if(cin.fail()) {
				cout << "\nYou have given an invalid input. Make sure your ID is a number that has 5 digits\n";
				cin.clear();
				cleanStandardInputStream();
			} else {
				if(ID > 9999 && ID <= 99999) {
					existsID = 0;
					for(int j = 0; j < static_cast<int>(source.getPassengers().size()); j++) {
						if(source.getPassengers().at(j).getID() == ID) {
								cout << "\nYou are  trying to use an ID that has already been assigned.\nPlease enter a different ID.\n";
								existsID = 1;
								break;
						}
					}
					if(!existsID) {
						cin.ignore();
						while(done) {
							cout << "Please enter the passenger first name: ";
							cin.getline(firstName, 20, '\n');
							if(cin.fail()) {
								cin.clear();
								cleanStandardInputStream();
								cout << "Something went wrong went reading the name or you inputted a name \nthat is longer than 19 characters. Try again.\n";
								validName = 0;
							} else {
								if(static_cast<int>(strlen(firstName)) > 0) {
									int k;
									dashCounter = 0;
									spaceCounter = 0;
									validName = 1;
									for(k = 0; k < static_cast<int>(strlen(firstName)); k++) {
										if(!(isalpha(firstName[k]))) {
											if(!(firstName[k] == '-')) {
												if(k > 0 && spaceCounter == 0) {
													spaceCounter++;
												} else {
													cout << "Your first name contains invalid characters. \nFirst name valid characters are alphabet characters and '-'.\n";
													validName = 0;
													break;
												}
											} else {
												if(dashCounter == 0) {
													if(k != 0) {
														dashCounter++;
													} else {
														cout << "The first name cannot start with a '-' character.\n";
														validName = 0;
														break;
													}
												}
												else {
													cout << "The first name inputted contains more than one '-'.\n";
													validName = 0;
													break;												
												}
											}
										}
									}
								} else {
									cout << "You cannot have an empty string first name.\n\n";
									validName = 0;
								}
							}
							if(validName) {
								while(done) {
									cout << "Please enter the passenger's Last Name: ";
									cin.getline(lastName, 18, '\n');
									if(cin.fail()) {
										cin.clear();
										cleanStandardInputStream();
										cout << "Something went wrong went reading the Last Name or you inputted a Last Name \nthat is longer than 17 characters. Try again.\n";
										validName = 0;
									} else {
										if(static_cast<int>(strlen(lastName)) > 0) {
											int k;
											dashCounter = 0;
											spaceCounter = 0;
											validName = 1;
											for(k = 0; k < static_cast<int>(strlen(lastName)); k++) {
												if(!(isalpha(lastName[k]))) {
													if(!(lastName[k] == '-')) {
														if(k > 0 && spaceCounter == 0 && lastName[k] == ' ') {
															spaceCounter++;
														} else {
															cout << "The Last Name contains invalid characters. \nLast Name valid characters are alphabet characters and '-'.\n";
															validName = 0;
															break;
														}
													} else {
														if(dashCounter == 0) {
															if(k != 0) {
																dashCounter++;
															} else {
																cout << "The Last Name cannot start with a '-' character.\n";
																validName = 0;
																break;
															}
														}
														else {
															cout << "The Last Name inputted contains more than one '-'.\n";
															validName = 0;
															break;												
														}
													}
												}
											}
										} else {
											cout << "You cannot have an empty Last Name input.\n\n";
											validName = 0;
										}
									}
									if(validName) {
										while(done) {
											validPhoneNumber = 1;
											cout << "Please enter the passenger phone number : ";
											cin.getline(phoneNumber, 13, '\n');
											if(cin.fail()) {
												cin.clear();
												cleanStandardInputStream();
												cout << "Something went wrong went reading the name or you inputted a phone number \nthat is longer than 12 characters. Try again.\n";
												validPhoneNumber = 0;
											} else {
												if(!(static_cast<int>(strlen(phoneNumber)) == 12)) {
													cout << "The phone number inputted must have the following format : XXX-XXX-XXXX , where X is a digit between 0 and 9.\n";
													validPhoneNumber = 0;
												} else {
													for(int z = 0; z < static_cast<int>(strlen(phoneNumber)); z++) {
														if(z < 3 || (z > 3 && z < 7) || (z > 7 && z <= 11)) {
															if(!isdigit(phoneNumber[z])) {
																validPhoneNumber = 0;
																cout << "The phone number inputted must have the following format : XXX-XXX-XXXX , where X is a digit between 0 and 9.\n";
																break;
															}
														} else {
															if(phoneNumber[z] != '-') {
																cout << "The phone number inputted must have the following format : XXX-XXX-XXXX , where X is a digit between 0 and 9.\n";
																validPhoneNumber = 0;
																break;
															}
														}
													}
												}
											}
											if(validPhoneNumber) {
												while(done) {
													cout << "\nPlease enter the passenger's desired row : ";
													cin >> row;
													if(cin.fail()) {
														cout << "\nYou have given an invalid input. Make sure your row is a number. b\n";
														cin.clear();
														cleanStandardInputStream();
													} else {
														if(row > 0 && row <= source.getRows()) {
															howManyInRow = 0;
															if(static_cast<int>(source.getPassengers().size()) > 0) {
																for(int m = 0; m < static_cast<int>(source.getPassengers().size()); m++) {
																	if(source.getPassengers().at(m).getSeat().getRow() == row) { 
																		howManyInRow++;
																	}
																}
															}
															if(howManyInRow != source.getSeats()) {
																cin.ignore();
																while(done) {
																	cout << "Please give the passenger's desired seat : ";
																	seat = cin.get();
																	if(seat == '\n') {
																		cout << "You have given an invalid input.\n";
																	}
																	else {
																		if((static_cast<int>(seat) - 64) <= source.getSeats() && static_cast<int>(seat) - 64 >= 0) {
																			seatTaken = 0;
																			if(static_cast<int>(source.getPassengers().size()) > 0) {
																				for(int m = 0; m < static_cast<int>(source.getPassengers().size()); m++) {
																					if(source.getPassengers().at(m).getSeat().getRow() == row && source.getPassengers().at(m).getSeat().getSeat() == seat) {
																						seatTaken = 1;
																						break;
																					}
																				}
																			}
																			if(!(seatTaken)) {
																				done = 0;
																			} else {
																				cout <<"You have given a seat that has been taken. Please try another seat.\n";
																				cin.ignore();
									
																			}
																		} else {
																			cout << "You have given an invalid input. Please give an input for the seat between A and"<< static_cast<char>(source.getSeats()+64) <<".\n\n";
																			cin.ignore();
																		}
																	}
																}
															} else {
																cout << "This Row is full. Please choose another one.\n";
															}
														} else {
															cout << "The flight has " << source.getRows() << " rows. Please input a number between 1 and ."<< source.getRows()<< "\n";
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				} else {
					cout << "\nYou have given an invalid input. Make sure your ID is a number that has 5 digits\n";
				}
			}
		}
		createdPassenger.setID(ID);
		createdPassenger.setFirstName(firstName);
		createdPassenger.setLastName(lastName);
		createdPassenger.setPhoneNumber(phoneNumber);
		createdPassenger.setSeat(row, seat);
		source.addPassenger(createdPassenger);
	}
	cin.ignore();
}
void removePassenger(Flight & source) {
	int ID;
	if(static_cast<int>(source.getPassengers().size()) == 0) {
		cout << "There are no passengers to be removed in this flight.\n";
	} else {
		while(1) {
			cout << "Please enter the ID of the passenger that needs to be removed : ";
			cin >> ID;
			if(cin.fail()) {
				cout << "You have given an ID that is not valid. Make sure the ID is a 5 digit number.\n";
				cin.clear();
				cleanStandardInputStream();
			} else {
				if(ID > 9999 && ID <= 99999) {
					int i;
					int sizeBeforeDelete = static_cast<int>(source.getPassengers().size());
					for(i = 0; i < sizeBeforeDelete; i++) {
						if(source.getPassengers().at(i).getID() == ID) {
							source.removePassenger(ID);
							cout << "Passenger with given ID successfully removed.\n";
							break;
						}
					}
					if(i == sizeBeforeDelete) {
						cout << "Passenger with given ID not found.\n";
					}
					break;
				} else {
					cout << "You are ID is not a 5 digit number.\n";
				}
			}
		}
	}
	cleanStandardInputStream();
}
void saveInformation(Flight & f){
	char choice;
	ofstream outputStream;
	while(1) {
		cout << "Do you want to save the data in the \"flight_info.txt\"? Please answer <Y or N> ";
		choice = cin.get();
		if(cin.fail()) {
			cout << "\nThere was an error with your input. Please try again.\n";
			cin.clear();
			cleanStandardInputStream();
		} else {
			if(choice == 'Y') {
				outputStream.open("flight_info.txt");
				if(outputStream.fail()) {
					cout << "There was an error opening the file. Operation cancelled.\n";
					outputStream.clear();
					break;
				}else {
					outputStream << setw(9) << setiosflags(ios::left) << f.getFlightName() << setw(6) << f.getRows() << f.getSeats() << "\n";
					for(int i = 0; i < static_cast<int>(f.getPassengers().size()); i++) {
						outputStream << setw(20) << f.getPassengers().at(i).getFirstName() << setw(20) << f.getPassengers().at(i).getLastName() << setw(20) << f.getPassengers().at(i).getPhoneNumber();
						if(f.getPassengers().at(i).getSeat().getRow() > 9) {
							outputStream << f.getPassengers().at(i).getSeat().getRow() << f.getPassengers().at(i).getSeat().getSeat() <<" "<< f.getPassengers().at(i).getID() << "\n";
						} else {
							outputStream << f.getPassengers().at(i).getSeat().getRow() << f.getPassengers().at(i).getSeat().getSeat() <<"  "<< f.getPassengers().at(i).getID() << "\n";
						}
					}
					cout <<"\nAll the data in the passenger list was saved in the flight_info.txt\n";
					outputStream.close();
					break;
				}
			}else if (choice == 'N') {
				cout << "\nYou chose not to save any data.\n";
				break;
			} else {
				cout << "\nYour input was not 'Y' or 'N'.Please try again.\n";
			}
		}
	}
	cin.ignore();
}
Flight populate_flight_from_file(string filename) {
	Flight f;
	Passenger createdPassenger;
	char flightName[10];
	int rows;
	int seats;
	char firstName[21];
	char lastName[21];
	char seatCharacters[5];
	int passengerRow;
	char passengerSeat;
	char phoneNumber[21];
	int passengerID;
	ifstream inputStream(filename);
	char * p;
	int dashCounter;
	int spaceCounter;
	int validName;
	int validPhoneNumber;
	if(inputStream.fail()) {
		cout << "There was an error opening the file... Program will now terminate.\n";
		exit(1);
	}
	while(1) {
		inputStream.get(flightName, 10);
		if(inputStream.eof())
			break;
		else if(inputStream.fail()) {
			cout << "Something went wrong while reading the flight name.\n";
			exit(1);
		}
		inputStream >> rows >> seats;
		if(inputStream.eof())
			break;
		else if(inputStream.fail()) {
			cout << "Something went wrong while reading flight seats and rows.\n";
		}
		p = flightName;
		while(*p != '\0') {
			if(*p == ' ') {
				*p = '\0';
				break;
			}
			p++;
		}
		f.setFlightName(flightName);
		f.setRows(rows);
		f.setSeats(seats);
		while(1) {
			inputStream.ignore();
			inputStream.get(firstName, 21);
			if(inputStream.eof())
				break;
			else if(inputStream.fail()) {
				cout << "Something went wrong while reading the passenger first name. Program will terminate.\n";
				exit(1);
				
			} else {
				if(static_cast<int>(strlen(firstName)) > 0) {
					int k;
					dashCounter = 0;
					spaceCounter = 0;
					validName = 1;
					for(k = 0; k < static_cast<int>(strlen(firstName)); k++) {
						if(!(isalpha(firstName[k]))) {
							if(!(firstName[k] == '-')) {
								if(k > 0 && spaceCounter == 0 && firstName[k] == ' ') {
									spaceCounter++;
								} else {
									if(spaceCounter == 1 && firstName[k] == ' ') {
										firstName[k] = '\0';
										break;
									} else {
										validName = 0;
										break;
									}
								}
							} else {
								if(dashCounter == 0) {
									if(k != 0) {
										dashCounter++;
									} else {
										validName = 0;
										break;
									}
								} else {
									validName = 0;
									break;												
								}
							}
						}
					}
				} else {
					validName = 0;
				}
				if(validName == 0) {
					cout << "There was an error with reading the passenger's first name. Program will terminate.\n";
					exit(1);
				}
			}
			inputStream.get(lastName, 21);
			if(inputStream.eof())
				break;
			else if(inputStream.fail()) {
				cout << "Something went wrong while reading the passenger last name. Program will terminate.\n";
				exit(1);
				
			} else {
				if(static_cast<int>(strlen(lastName)) > 0) {
					int k;
					dashCounter = 0;
					spaceCounter = 0;
					validName = 1;
					for(k = 0; k < static_cast<int>(strlen(lastName)); k++) {
						if(!(isalpha(lastName[k]))) {
							if(!(lastName[k] == '-')) {
								if(k > 0 && spaceCounter == 0 && lastName[k] == ' ') {
									spaceCounter++;
								} else {
									if(spaceCounter == 1 && lastName[k] == ' ') {
										lastName[k] = '\0';
										break;
									} else {
										validName = 0;
										break;
									}
								}
							} else {
								if(dashCounter == 0) {
									if(k != 0) {
										dashCounter++;
									} else {
										validName = 0;
										break;
									}
								} else {
									validName = 0;
									break;												
								}
							}
						}
					}
				} else {
					validName = 0;
				}
				if(validName == 0) {
					cout << "there was an error with reading the passenger's last name. Program will terminate.\n";
					exit(1);
				}
			}
			validPhoneNumber = 1;
			inputStream.get(phoneNumber, 21);
			if(inputStream.eof())
				break;
			else if(inputStream.fail()) {
				cout << "Something went wrong went reading the phone number of the passenger. Program will terminate.\n";
				exit(1);
			} else {
				phoneNumber[12] = '\0';
				if(!(static_cast<int>(strlen(phoneNumber)) == 12)) {
					validPhoneNumber = 0;
				} else {
					for(int z = 0; z < static_cast<int>(strlen(phoneNumber)); z++) {
						if(z < 3 || (z > 3 && z < 7) || (z > 7 && z <= 11)) {
							if(!isdigit(phoneNumber[z])) {
								validPhoneNumber = 0;
							break;
							}
						} else {
							if(phoneNumber[z] != '-') {
								validPhoneNumber = 0;
								break;
							}
						}
					}
				}
				if(validPhoneNumber == 0) {
					cout << "There was an error while reading the phone number of the passenger. Program will terminate.\n";
					exit(1);
				}
			}
			inputStream.get(seatCharacters, 5);
			if(inputStream.eof())
				break;
			else if(inputStream.fail()) {
				cout << "There was an error while reading the row and seat.Program will be terminated.\n";
				exit(1);
			} else {
				p = seatCharacters;
				while(*p != '\0') {
					if(*p == ' ') {
						*p = '\0';
						break;
					}
					p++;
				}
				passengerRow = 0;
				for(int i = 0; i < static_cast<int>(strlen(seatCharacters)); i++) {
					if(isdigit(seatCharacters[i])) {
						passengerRow = passengerRow*10 + static_cast<int>(seatCharacters[i]) - 48;
					} else {
						passengerSeat = seatCharacters[i];
					}
				}
			}
			inputStream >> passengerID;
			if(inputStream.eof())
				break;
			else if(inputStream.fail()) {
				cout << "There was an error reading the passenger ID. Program will be terminated.\n";
				exit(1);
			} else {
				if(!(passengerID > 9999 && passengerID <= 99999)) {
					cout << "passengerID needs to be a 5 digit number. Program will be terminated.\n";
					exit(1);
				}
			}

			createdPassenger.setID(passengerID);
			createdPassenger.setFirstName(firstName);
			createdPassenger.setLastName(lastName);
			createdPassenger.setPhoneNumber(phoneNumber);
			createdPassenger.setSeat(passengerRow, passengerSeat);
			f.addPassenger(createdPassenger);
		}
		break;
	}
	inputStream.close();
	return f;
}